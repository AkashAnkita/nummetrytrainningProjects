package com.javatechie.crud.example.service;

import com.javatechie.crud.example.entity.Studentdata;
import com.javatechie.crud.example.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    @Autowired
    private StudentRepository repository;

    public Studentdata saveStudent(Studentdata student) {
        return repository.save(student);
    }

    public List<Studentdata> saveStudents(List<Studentdata> student) {
        return repository.saveAll(student);
    }

    public List<Studentdata> getStudents() {
        return repository.findAll();
    }

    public Studentdata getStudentById(int id) {
        return repository.findById(id).orElse(null);
    }

    public Studentdata getStudentByName(String name) {
        return repository.findByName(name);
    }

    public String deleteStudent(int id) {
        repository.deleteById(id);
        return "product removed !! " + id;
    }

   

}
