package com.javatechie.crud.example.controller;

import com.javatechie.crud.example.entity.Studentdata;
import com.javatechie.crud.example.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class StudentController {

    @Autowired
    private StudentService service;

    @PostMapping("/addStudent")
    public Studentdata addStudent(@RequestBody Studentdata student) {
        return service.saveStudent(student);
    }

    @PostMapping("/addStudents")
    public List<Studentdata> addStudents(@RequestBody List<Studentdata> students) {
        return service.saveStudents(students);
    }

    @GetMapping("/students")
    public List<Studentdata> findAllStudents() {
        return service.getStudents();
    }

    @GetMapping("/StudentById/{id}")
    public Studentdata findStudentById(@PathVariable int id) {
        return service.getStudentById(id);
    }

    @GetMapping("/student/{name}")
    public Studentdata findStudentByName(@PathVariable String name) {
        return service.getStudentByName(name);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteStudent(@PathVariable int id) {
        return service.deleteStudent(id);
    }
}
