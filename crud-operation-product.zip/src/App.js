import logo from './logo.svg';
import './App.css';
import Productcomponent from './productcomponent';
import ProductCreate from './ProductCreate';
import ProductDetail from './ProductDetail';
import ProductEdit from './ProductEditing';
import { BrowserRouter, Route, Routes } from 'react-router-dom'


function App() {
  return (
    <div className="App">
    <h1>React JS CRUD Opertations</h1>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Productcomponent />}></Route>
        <Route path='/product/create' element={<ProductCreate />}></Route>
        <Route path='/product/detail' element={<ProductDetail />}></Route>
        <Route path='/product/edit' element={<ProductEdit />}></Route>
        </Routes>
        </BrowserRouter>
        </div>
  );
}

export default App;