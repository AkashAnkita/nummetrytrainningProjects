import axios from "axios";
const rest_APi='http://localhost:8080';

export const listProducts=()=>
     axios.get(rest_APi);
