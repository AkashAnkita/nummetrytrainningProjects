import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";


const ProductDetail = () => {
    const { empid } = useParams();

    const [empdata, empdatachange] = useState({});

    useEffect(() => {
        fetch('http://localhost:8080/' + empid
    ).then((res) => {
            return res.json();
        }).then((resp) => {
            empdatachange(resp);
        }).catch((err) => {
            console.log(err.message);
        })
    }, []);
    return (
        <div>
            {/* <div className="row">
                <div className="offset-lg-3 col-lg-6"> */}

               <div className="container">
                
            <div className="card row" style={{ "textAlign": "left" }}>
                <div className="card-title">
                    <h2>Product Create</h2>
                </div>
                <div className="card-body"></div>

                {empdata &&
                    <div>
                        <h2>The Product name is : <b>{empdata.productName}</b>  ({empdata.productId})</h2>
                        <h3>Product Details</h3>
                        <h5>Price is : {empdata.price}</h5>
                        <h5>Description is : {empdata.des}</h5>
                        <Link className="btn btn-danger" to="/">Back to Listing</Link>
                    </div>
                }
            </div>
            </div>
            {/* </div>
            </div> */}
        </div >
    );
}

export default ProductDetail;