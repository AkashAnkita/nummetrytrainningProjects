import React, { useEffect, useState } from "react";
import { auth, db } from "./firebase";
import { doc, getDoc } from "firebase/firestore";
import { FiAlignJustify } from "react-icons/fi";
import { BiBookmark , BiConversation ,BiGroup } from "react-icons/bi";
import { MdDashboard } from "react-icons/md";
import { IoLogoXbox } from "react-icons/io5";
import { SiCoursera } from "react-icons/si";
import { MdOutlineScreenSearchDesktop } from "react-icons/md";
import { FaSignOutAlt } from "react-icons/fa";
import { RiFindReplaceFill } from "react-icons/ri";
import Banner from "./banner";


function Profile() {
  const [userDetails, setUserDetails] = useState(null);
  const fetchUserData = async () => {
    auth.onAuthStateChanged(async (user) => {
      console.log(user);

      const docRef = doc(db, "Users", user.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setUserDetails(docSnap.data());
        console.log(docSnap.data());
      } else {
        console.log("User is not logged in");
      }
    });
  };
  useEffect(() => {
    fetchUserData();
  }, []);

  async function handleLogout() {
    try {
      await auth.signOut();
      window.location.href = "/login";
      console.log("User logged out successfully!");
    } catch (error) {
      console.error("Error logging out:", error.message);
    }
    // document.addEventListener("DOMContentLoaded", function (event) {

    //   const showNavbar = (toggleId, navId, bodyId, headerId) => {
    //     const toggle = document.getElementById(toggleId),
    //       nav = document.getElementById(navId),
    //       bodypd = document.getElementById(bodyId),
    //       headerpd = document.getElementById(headerId)

    //     // Validate that all variables exist
    //     if (toggle && nav && bodypd && headerpd) {
    //       toggle.addEventListener('click', () => {
    //         // show navbar
    //         nav.classList.toggle('show')
    //         // change icon
    //         toggle.classList.toggle('bx-x')
    //         // add padding to body
    //         bodypd.classList.toggle('body-pd')
    //         // add padding to header
    //         headerpd.classList.toggle('body-pd')
    //       })
    //     }
    //   }

    //   showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

    //   /*===== LINK ACTIVE =====*/
    //   const linkColor = document.querySelectorAll('.nav_link')

    //   function colorLink() {
    //     if (linkColor) {
    //       linkColor.forEach(l => l.classList.remove('active'))
    //       this.classList.add('active')
    //     }
    //   }
    //   linkColor.forEach(l => l.addEventListener('click', colorLink))

    //   // Your code to run since DOM is loaded and ready
    // });
  }
// function hidenav(){

// }
  return (
    <div>
      <header className="header" id="header">
      {/* <div className="header_toggle" onClick={hidenav}>  <FiAlignJustify /> </div> */}

        {userDetails ? (
          <>

            <div>


              <p
                style={{

                  display: "list-item"
                }}>


                <span style={{ padding: "30px" }}>Welcome {userDetails.firstName}</span>


                <span style={{ padding: "30px" }}>Home </span>
                {/* <span style={{ padding: "30px" }}>Courses</span>
                <span style={{ padding: "30px" }}>Jobs</span> */}
                {/* <span style={{ padding: "30px" }}>P</span> */}
                <span style={{ padding: "30px" }}>About Us</span>
                <span style={{ padding: "30px" }}>Contact us</span>
                {/* <button className="btn btn-primary"style={{padding: "10px"}} onClick={handleLogout}> Logout</button> */}
              </p>

            </div>
          </>
        ) : (<></>)}
        <div className="header_img"> <img src={require("../numetry_technologies_logo.jpg")}  alt="" /> </div>


      </header>
      <div className="l-navbar" id="nav-bar">
        <nav className="nav">
          <div> <a href="#" className="nav_logo">
          <IoLogoXbox/>
            <span className="nav_logo-name">Nummetry Trainning</span> </a>
            <div className="nav_list">
              <a href="#" className="nav_link active">
                <MdDashboard/>
                <span className="nav_name">Dashboard</span> </a>
              {/* <a href="#" className="nav_link">
                <BiGroup/>
                <span className="nav_name">Users</span> </a>
              <a href="#" className="nav_link">
                < BiConversation/>
                <span className="nav_name">Messages</span> </a> */}
              {/* <a href="#" className="nav_link">
              <BiBookmark />
                <span className="nav_name">Bookmark</span> </a> */}
              <a href="#" className="nav_link">
              <SiCoursera />
                <span className="nav_name">Courses
  
                  </span>
                 </a>
              <a href="#" className="nav_link">
              <MdOutlineScreenSearchDesktop />
                <span className="nav_name">Jobs</span>
              </a>
              <a href="#" className="nav_link">
              <RiFindReplaceFill />
                <span className="nav_name">Placements</span>
              </a>
            </div>
          </div>
          <a href="#" className="nav_link">
          <FaSignOutAlt />

            <span className="nav_name" onClick={handleLogout}>SignOut</span>
          </a>
        </nav>
      </div>

      <div className="h-500 bg-light" style={{marginTop:"100px"}}>
<Banner/>
        <h4>Main Components</h4>
      </div>
    </div>
    //  {userDetails ? (
    //         <>

    //           <div style={{ display: "inline", height:"300px" }}>


    //           <p 
    //            style={{
    //   padding: "10px",
    //   margin: "20px",  
    //   display:"list-item"
    // }}>


    //           <span style={{padding: "20px",marginLeft:"-100px" }}>Welcome {userDetails.firstName}</span>


    //             <span className="mb-3"style={{padding: "20px"}}>Home </span>
    //             <span className="mb-3"style={{padding: "20px"}}>Courses</span>
    //             <span className="mb-3"style={{padding: "20px"}}>About Us</span>
    //             <span className="mb-3"style={{padding: "20px"}}>Contact us</span>
    //             <button className="btn btn-primary"style={{padding: "10px"}} onClick={handleLogout}> Logout</button>
    //             </p>
    //             {/* <p>Last Name: {userDetails.lastName}</p> */}
    //           </div>
    //         </>
    //       ) : (
    //         <p>Loading...</p>
    //       )}
    //     </div>

  );
}
export default Profile;
