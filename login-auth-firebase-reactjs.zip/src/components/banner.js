import React from 'react'
import { GoDotFill } from "react-icons/go";
import { FaArrowRight } from "react-icons/fa";

function Banner() {
  return (
    <div>
      <div className='container' style={{ width:"100%",height:"80vh"}}>
<img src={require('../1.jpg')}style={{marginTop:"10px",height:"400px", borderRadius:"2em",width:"150px", marginLeft:"248px"}}></img>
<img src={require('../2.jpg')}style={{marginLeft:"800px", marginTop:"-295px",height:"400px", borderRadius:"2em",width:"150px"}}></img>
<h1 style={{marginLeft:"-560px",marginTop:"-510px",color:"black"
}} >Elevate your skills ,<br/> Elevate your carrer with Nummetry </h1>
<span className='courses'>Our Courses</span>

      <li className='list'> <GoDotFill/> Java fullStack Development</li>
        <li className='list'> <GoDotFill/> Software Testing</li>
        <li className='list'> <GoDotFill/> Data Science</li>
        <li className='list'> <GoDotFill/> Web Development</li>
        <li className='list'> <GoDotFill/> MERN</li>
        <li className='list'> <GoDotFill/> Python fullStack Development</li>
        <li className='list'> <GoDotFill/> Data Analysis</li>
<br/>
<br/>
        <button className="btn btn-primary "style={{padding: "10px ",background:"green",marginLeft:"-610px" ,fontSize:"1.3em"}}> Enquire Now</button> 
        <button className="btn btn-primary"style={{padding: "10px",background:"green",marginLeft:"-310px",fontSize:"1.3em"}} > Apply Now</button> 
      </div>
      <br/>
      <br/>
<div className='about'>

    <h1>
    Nummetry Training: Software Training Institute
    </h1>
    <p style={{fontSize:"1.2em"}}>
    Welcome to the Nummetry the pinnacle of excellence in the Software Training Institute. At Cyber ​​Success – IT Training Institute we go beyond traditional education, offering curriculum that empowers individuals in the dynamic technological world. As a leading software training institute in Pune, India, we specialize in a variety of courses, including software testing (manual testing and  automation testing), Python development, Java development, data science, cloud computing, etc. 
    </p>
    <br/>
    <button className="btn btn-primary"style={{padding: "10px",background:"green",marginLeft:"15px",fontSize:"1.3em"}} >Read More
  <FaArrowRight/>      </button> 

</div>
<br/>
<br/>
<br/>
<div>
    <h1>Transform Your Career: Software Training Institute Unveils Specialized Courses</h1>
    <section class="container">
      <div class="card__container swiper">
         <div class="card__content">
            <div class="swiper-wrapper">
               <article class="card__article swiper-slide ">
                  <div class="card__image">
                     <img src={require("../images.jpg")} alt="image" class="card__img"/>
                     <div class="card__shadow"></div>
                  </div>

                  <div class="card__data ">
                     <h3 class="card__name">Python For
                        AI</h3>
                     <p class="card__description">
                        Python is a widely used programming language for artificial intelligence (AI) and machine
                        learning (ML). It is a fast, secure, reliable
                     </p>

                     <a href="python.html" class="card__button">View More</a>
                  </div>
               </article>

               <article class="card__article swiper-slide">
                  <div class="card__image">
                     <img src={require("../java.jpg")} alt="image" class="card__img"/>
                  </div>

                  <div class="card__data ">
                     <h3 class="card__name">Java Technology</h3>
                     <p class="card__description">
                        Java is a multi-platform, object-oriented, and network-centric language that can be used as a
                        platform in itself. It is a fast, secure, reliable
                     </p>

                     <a href="java.html" class="card__button">View More</a>
                  </div>
               </article>

               <article class="card__article swiper-slide">
                  <div class="card__image">
                     <img src={require("../htmlnew.jpg")} alt="image" class="card__img"/>
                     <div class="card__shadow"></div>
                  </div>

                  <div class="card__data ">
                     <h3 class="card__name">HTML</h3>
                     <p class="card__description">
                        HyperText Markup Language is the standard markup language for documents designed to be displayed
                        in a web browser.
                        It defines the content and structure of web content. </p>

                     <a href="web.html" class="card__button">View More</a>
                  </div>
               </article>

               <article class="card__article swiper-slide">
                  <div class="card__image">
                     <img src={require("../javascript.png")} alt="image" class="card__img"/>
                     <div class="card__shadow"></div>
                  </div>

                  <div class="card__data">
                     <h3 class="card__name">JavaScript</h3>
                     <p class="card__description">
                        JavaScript, often abbreviated as JS, is a programming language and core technology of the Web,
                        alongside HTML and CSS </p>

                     <a href="javascript.html" class="card__button">View More</a>
                  </div>
               </article>

               <article class="card__article swiper-slide">
                  <div class="card__image">
                     <img src={require("../mongo.png")} alt="image" class="card__img"/>
                    
                  </div>

                  <div class="card__data">
                     <h3 class="card__name">MongoDB</h3>
                     <p class="card__description">
                        MongoDB is a source-available, cross-platform, document-oriented database program. MongoDB is
                        developed by MongoDB Inc. </p>

                     <a href="#" class="card__button">View More</a>
                  </div>
               </article>
            </div>
         </div>
         </div>
         </section>
</div>

    </div>
  )
}

export default Banner
