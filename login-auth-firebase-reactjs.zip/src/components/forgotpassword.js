import { sendPasswordResetEmail } from "firebase/auth";
import React, { useState,useNavigate } from "react";
import { auth, db } from "./firebase";


function ForgotPassword(){
    // const history = useNavigate();
    const [email, setEmail] = useState("");
    const handleSubmit = async(e)=>{
        e.preventDefault()
        try{
        await sendPasswordResetEmail (auth, email);

        // sendPasswordResetEmail(db,emalVal).then(data=>{
            alert("Check your gmail")
            window.location.href = "/login";

        }
        catch(err){
            alert(err.code)
        }
}
    return(
        <div className="App">
             <div className="auth-wrapper">
             <div className="auth-inner">
            <h1 style={{color:"black"}}>Forgot Password</h1>
             <form onSubmit={(e)=>handleSubmit(e)}>
                {/* <input name="email" /><br/><br/> */} 
                 <input
          type="email"
          className="form-control"
          placeholder="Enter email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
                <button>Reset</button>
            </form>
        </div>
        </div>
        </div>
    )
}
export default ForgotPassword;