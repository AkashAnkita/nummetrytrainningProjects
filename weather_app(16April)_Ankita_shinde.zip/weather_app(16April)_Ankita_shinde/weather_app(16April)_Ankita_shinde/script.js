//****************we.html*******************************

// const wrapper = document.querySelector(".wrapper"),
// inputPart = document.querySelector(".input-part"),
// infoTxt = inputPart.querySelector(".info-txt"),
// inputField = inputPart.querySelector("input"),
// locationBtn = inputPart.querySelector("button"),
// weatherPart = wrapper.querySelector(".weather-part"),
// wIcon = weatherPart.querySelector("img"),
// arrowBack = wrapper.querySelector("header i");

// let api;

// inputField.addEventListener("keyup", e =>{
//     if(e.key == "Enter" && inputField.value != ""){
//         requestApi(inputField.value);
//     }
// });

// locationBtn.addEventListener("click", () =>{
//     if(navigator.geolocation){
//         navigator.geolocation.getCurrentPosition(onSuccess, onError);
//     }else{
//         alert("Your browser not support geolocation api");
//     }
// });

// function requestApi(city){
//     api = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=338952da2aa3ea9363afaeb796daf006`;
//     fetchData();
// }

// function onSuccess(position){
//     const {latitude, longitude} = position.coords;
//     api = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=338952da2aa3ea9363afaeb796daf006`;
//     fetchData();
// }

// function onError(error){
//     infoTxt.innerText = error.message;
//     infoTxt.classList.add("error");
// }

// function fetchData(){
//     infoTxt.innerText = "Getting weather details...";
//     infoTxt.classList.add("pending");
//     fetch(api).then(res => res.json()).then(result => weatherDetails(result)).catch(() =>{
//         infoTxt.innerText = "Something went wrong";
//         infoTxt.classList.replace("pending", "error");
//     });
// }

// function weatherDetails(info){
//     if(info.cod == "404"){
//         infoTxt.classList.replace("pending", "error");
//         infoTxt.innerText = `${inputField.value} isn't a valid city name`;
//     }else{
//         const city = info.name;
//         const country = info.sys.country;
//         const {description, id} = info.weather[0];
//         const {temp, feels_like, humidity} = info.main;

//         if(id == 800){
//             wIcon.src = "icons/clear.svg";
//         }else if(id >= 200 && id <= 232){
//             wIcon.src = "icons/storm.svg";  
//         }else if(id >= 600 && id <= 622){
//             wIcon.src = "icons/snow.svg";
//         }else if(id >= 701 && id <= 781){
//             wIcon.src = "icons/haze.svg";
//         }else if(id >= 801 && id <= 804){
//             wIcon.src = "icons/cloud.svg";
//         }else if((id >= 500 && id <= 531) || (id >= 300 && id <= 321)){
//             wIcon.src = "icons/rain.svg";
//         }
        
//         weatherPart.querySelector(".temp .numb").innerText = Math.floor(temp);
//         weatherPart.querySelector(".weather").innerText = description;
//         weatherPart.querySelector(".location span").innerText = `${city}, ${country}`;
//         weatherPart.querySelector(".temp .numb-2").innerText = Math.floor(feels_like);
//         weatherPart.querySelector(".humidity span").innerText = `${humidity}%`;
//         infoTxt.classList.remove("pending", "error");
//         infoTxt.innerText = "";
//         inputField.value = "";
//         wrapper.classList.add("active");
//     }
// }

// arrowBack.addEventListener("click", ()=>{
//     wrapper.classList.remove("active");
// });


//**************************************************************************************************************************






const cityInput = document.querySelector(".city-input");
const searchButton = document.querySelector(".search-btn");
const locationButton = document.querySelector(".location-btn");
const currentWeatherDiv = document.querySelector(".current-weather");
const weatherCardsDiv = document.querySelector(".weather-cards");



const createWeatherCard = (cityName, weatherItem, index) => {
    if(index === 0) { 
        return `<div class="details">
                    <h2>${cityName} (${weatherItem.dt_txt.split(" ")[0]})</h2>
                    <h6>Temperature: ${(weatherItem.main.temp - 273.15).toFixed(2)}°C</h6>
                    <h6>Wind: ${weatherItem.wind.speed} M/S</h6>
                    <h6>Humidity: ${weatherItem.main.humidity}%</h6>
                </div>
                <div class="icon">
                    <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@4x.png" alt="weather-icon">
                    <h6>${weatherItem.weather[0].description}</h6>
                </div>`;
    } else { 
        return `<li class="card">
                    <h3>(${weatherItem.dt_txt.split(" ")[0]})</h3>
                    <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@4x.png" alt="weather-icon">
                    <h6>Temp: ${(weatherItem.main.temp - 273.15).toFixed(2)}°C</h6>
                    <h6>Wind: ${weatherItem.wind.speed} M/S</h6>
                    <h6>Humidity: ${weatherItem.main.humidity}%</h6>
                </li>`;
    }
}

const getWeatherDetails = (cityName, latitude, longitude) => {
    const WEATHER_API_URL = `https://api.openweathermap.org/data/2.5/forecast?lat=${latitude}&lon=${longitude}&appid=338952da2aa3ea9363afaeb796daf006`;

    fetch(WEATHER_API_URL).then(response => response.json()).then(data => {
        
        const uniqueForecastDays = [];
        const fiveDaysForecast = data.list.filter(forecast => {
            const forecastDate = new Date(forecast.dt_txt).getDate();
            if (!uniqueForecastDays.includes(forecastDate)) {
                return uniqueForecastDays.push(forecastDate);
            }
        });

        
        cityInput.value = "";
        currentWeatherDiv.innerHTML = "";
        weatherCardsDiv.innerHTML = "";

        
        fiveDaysForecast.forEach((weatherItem, index) => {
            const html = createWeatherCard(cityName, weatherItem, index);
            if (index === 0) {
                currentWeatherDiv.insertAdjacentHTML("beforeend", html);
            } else {
                weatherCardsDiv.insertAdjacentHTML("beforeend", html);
            }
        });        
    }).catch(() => {
        alert("An error occurred while fetching the weather forecast!");
    });
}

const getCityCoordinates = () => {
    const cityName = cityInput.value.trim();
    if (cityName === "") return;
    const API_URL = `https://api.openweathermap.org/geo/1.0/direct?q=${cityName}&limit=1&appid=338952da2aa3ea9363afaeb796daf006`;
    
    
    fetch(API_URL).then(response => response.json()).then(data => {
        if (!data.length) return alert(`No coordinates found for ${cityName}`);
        const { lat, lon, name } = data[0];
        getWeatherDetails(name, lat, lon);
    }).catch(() => {
        alert("An error occurred while fetching the coordinates!");
    });
}

const getUserCoordinates = () => {
    navigator.geolocation.getCurrentPosition(
        position => {
            const { latitude, longitude } = position.coords;
            const API_URL = `https://api.openweathermap.org/geo/1.0/reverse?lat=${latitude}&lon=${longitude}&limit=1&appid=338952da2aa3ea9363afaeb796daf006`;
            fetch(API_URL).then(response => response.json()).then(data => {
                const { name } = data[0];
                getWeatherDetails(name, latitude, longitude);
            }).catch(() => {
                alert("An error occurred while fetching the city name!");
            });
        },
        error => { 
            if (error.code === error.PERMISSION_DENIED) {
                alert("Geolocation request denied. Please reset location permission to grant access again.");
            } else {
                alert("Geolocation request error. Please reset location permission.");
            }
        });
}

locationButton.addEventListener("click", getUserCoordinates);
searchButton.addEventListener("click", getCityCoordinates);
cityInput.addEventListener("keyup", e => e.key === "Enter" && getCityCoordinates());